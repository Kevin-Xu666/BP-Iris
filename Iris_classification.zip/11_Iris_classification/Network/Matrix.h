#ifndef _MATRIX_H_
#define _MATRIX_H_
#include <functional>
#include <vector>
#include <ctime>
#include <random>
#include <iostream>
template<typename Dtype>
class Matrix{
    // ģ����Matrix��ģ�����;�������Ԫ�ص���������
public:
	int row;
	int col;
	std::vector<std::vector<Dtype>> data;
	using VV = std::vector<std::vector<Dtype>>;

	Matrix();
	Matrix(int _Row, int _Column, Dtype init = 0);
	Matrix(const Matrix& mat);
	Matrix(Matrix&& mat) noexcept;
	~Matrix() {};
	void free();
	Matrix& operator=(const Matrix& mat);
	Matrix& operator=(Matrix&& mat) noexcept;

	void uniform_(Dtype inf, Dtype sup);
	void xavier_(int ind, int oud);
	Dtype& operator() (int r, int c);
	Matrix T() const;
	void Set_Matrix(std::vector<Dtype> arr);

	Matrix apply(const std::function<Dtype(Dtype)>& fun) const;
	Matrix& apply_(const std::function<Dtype(Dtype)>& fun);
	Matrix& operator+= (const Matrix&);
	Matrix operator+ (const Matrix&) const;
	Matrix operator+ (const Dtype) const;

	Matrix& operator-();
	Matrix& operator-= (const Matrix&);
	Matrix operator- (const Matrix&) const;

	Matrix operator/ (const Dtype) const;
	Matrix operator/(const Matrix&) const; // element-wise, not inverse
	Matrix operator* (const Dtype) const;
	Matrix operator*(const Matrix&) const;

	Matrix operator& (const Matrix&) const; // Hadamard product

	Matrix power_n(int) const;
	Dtype Ln_norm(int) const;
	Dtype sum() const;

	std::pair<int, Dtype> max() const;

	void out() const;
};


// defination
template<typename Dtype>
Matrix<Dtype>::Matrix() {
    row = col = 0;
    data = VV();
}

template<typename Dtype>
Matrix<Dtype>::Matrix(int _row, int _column, Dtype init) {
    // �������кͳ�ʼֵ�Ĺ��캯������ʼֵĬ��Ϊ0
    row = _row;
    col = _column;
    if (row * col) {
        for (int i = 0; i < row; ++i) {
            data.push_back(std::vector<Dtype>(col, init));
        }
    }
    else {
        row = col = 0;
        data = VV();
    }
}

template<typename Dtype>
Matrix<Dtype>::Matrix(const Matrix<Dtype>& mat)
    : Matrix(mat.row, mat.col) {
    // �������캯��
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            data[i][j] = mat.data[i][j];
        }
    }
}

template<typename Dtype>
Matrix<Dtype>::Matrix(Matrix<Dtype>&& mat) noexcept {
    // �ƶ����캯��
    row = mat.row;
    col = mat.col;
    data = std::move(mat.data);
}


template<typename Dtype>
inline void Matrix<Dtype>::free() {
    // ��վ���
    row = col = 0;
    data = VV();
}

template<typename Dtype>
inline Matrix<Dtype>& Matrix<Dtype>::operator=(const Matrix<Dtype>& mat) {
    // ������ֵ�����
    row = mat.row;
    col = mat.col;
    data = mat.data;
    return *this;
}

template<typename Dtype>
inline Matrix<Dtype>& Matrix<Dtype>::operator=(Matrix<Dtype>&& mat) noexcept {
    // �ƶ���ֵ�����
    row = mat.row;
    col = mat.col;
    data = std::move(mat.data);
    return *this;
}

template<typename Dtype>
inline void Matrix<Dtype>::uniform_(Dtype inf, Dtype sup) {
    // ������ɷ��Ͼ��ȷֲ��ľ���Ԫ��
    std::uniform_real_distribution<Dtype> u(inf, sup);
    std::default_random_engine e;
    e.seed(std::time(nullptr));
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            data[i][j] = u(e);
        }
    }
}

template<typename Dtype>
inline void Matrix<Dtype>::xavier_(int ind, int oud) {
    // Xavier��ʼ����ʹ���˷���У���ľ��ȷֲ�
    double bound = sqrt(6 / (ind + oud));
    std::uniform_real_distribution<Dtype> u(-bound, bound);
    std::default_random_engine e;
    e.seed(std::time(nullptr));
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            data[i][j] = u(e);
        }
    }
}

template<typename Dtype>
inline Dtype& Matrix<Dtype>::operator() (int r, int c) {
    // Ԫ�ط��ʣ�����һ����ֵ����
    Dtype& ref = data[r][c];
    return ref;
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::T() const {
    // ����ת��
    Matrix<Dtype> new_mat(this->col, this->row);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            new_mat.data[j][i] = data[i][j];
        }
    }
    return new_mat;
}

template<typename Dtype>
inline void Matrix<Dtype>::Set_Matrix(std::vector<Dtype> arr) {
    // ��һ�������й������Ԫ�أ��Դ����Ҵ��ϵ��µ�˳�����
    for (int k = 0; k < arr.size(); ++k) {
        data[k / col][k % col] = arr[k];
    }
}


template<typename Dtype>
Matrix<Dtype> Matrix<Dtype>::apply(const std::function<Dtype(Dtype)>& fun) const {
    // �Ծ����е�ÿ��Ԫ��Ӧ�ú���fun������for_each������һ���¾���
    Matrix<Dtype> new_mat(this->row, this->col);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            new_mat.data[i][j] = fun(data[i][j]);
        }
    }
    return new_mat;
}

template<typename Dtype>
Matrix<Dtype>& Matrix<Dtype>::apply_(const std::function<Dtype(Dtype)>& fun) {
    // �ھ���ԭַ��Ԫ��Ӧ�ú���fun
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            data[i][j] = fun(data[i][j]);
        }
    }
    return *this;
}

template<typename Dtype>
inline Matrix<Dtype>& Matrix<Dtype>::operator+= (const Matrix<Dtype>& rmat) {
    if (row != rmat.row || col != rmat.col) {
        throw "PLUS ERROR: Size not match.\n";
    }
    else {
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                data[i][j] += rmat.data[i][j];
            }
        }
        return *this;
    }
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator+ (const Matrix<Dtype>& rmat) const {
    // ��+=����ӷ�
    Matrix<Dtype> new_mat(*this);
    new_mat += rmat;
    return new_mat;
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator+ (const Dtype C) const {
    Matrix<Dtype> new_mat(*this);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            new_mat.data[i][j] += C;
        }
    }
    return new_mat;
}


template<typename Dtype>
inline Matrix<Dtype>& Matrix<Dtype>::operator-() {
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            data[i][j] = -data[i][j];
        }
    }
    return *this;
}

template<typename Dtype>
inline Matrix<Dtype> operator-(const Dtype C, Matrix<Dtype>& mat) {
    Matrix<Dtype> new_mat(mat);
    for (int i = 0; i < mat.row; ++i) {
        for (int j = 0; j < mat.col; ++j) {
            new_mat.data[i][j] = C - new_mat.data[i][j];
        }
    }
    return new_mat;
}

template<typename Dtype>
Matrix<Dtype>& Matrix<Dtype>::operator-= (const Matrix<Dtype>& rmat) {
    if (row != rmat.row || col != rmat.col) {
        throw "SUBTRACT ERROR: Size not match.\n";
    }
    else {
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                data[i][j] -= rmat.data[i][j];
            }
        }
        return *this;
    }
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator- (const Matrix<Dtype>& rmat) const {
    Matrix<Dtype> new_mat(*this);
    new_mat -= rmat;
    return new_mat;
}


template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator/ (const Dtype C) const {
    Matrix<Dtype> new_mat(*this);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            new_mat.data[i][j] /= C;
        }
    }
    return new_mat;
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator/(const Matrix<Dtype>& rmat) const {
    // ������Ԫ�صĳ���
    if (row != rmat.row || col != rmat.col) {
        throw "DIV ERROR: Size not match.\n";
    }
    else {
        Matrix<Dtype> new_mat(*this);
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                new_mat.data[i][j] /= rmat.data[i][j];
            }
        }
        return new_mat;
    }
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator* (const Dtype C) const {
    Matrix<Dtype> new_mat(*this);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            new_mat.data[i][j] *= C;
        }
    }
    return new_mat;
}

template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator*(const Matrix<Dtype>& rmat) const {
    if (rmat.row != col) {
        throw "MUL ERROR: Size not match.\n";
    }
    else {
        Matrix<Dtype> new_mat(row, rmat.col);
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < rmat.col; ++j) {
                new_mat.data[i][j] = data[i][0] * rmat.data[0][j];
                for (int k = 1; k < col; ++k) {
                    new_mat.data[i][j] += data[i][k] * rmat.data[k][j];
                }
            }
        }
        return new_mat;
    }
}

// Hadamard or dot product
template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::operator& (const Matrix<Dtype>& rmat) const {
    // �����ڻ������Hadamard�����궨��Ϊ 'DOT'
    if (row != rmat.row || col != rmat.col) {
        throw "HADAMARD ERROR: Size not match.\n";
    }
    else {
        Matrix<Dtype> new_mat(*this);
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                new_mat.data[i][j] *= rmat.data[i][j];
            }
        }
        return new_mat;
    }
}
#define DOT &


// utility
template<typename Dtype>
void Matrix<Dtype>::out() const {
    if (col == 1) {
        for (int j = 0; j < col; ++j) {
            for (int i = 0; i < row; ++i) {
                std::cout << data[i][j] << ' ';
            }std::cout << '\n';
        }
    }
    else {
        for (int i = 0; i < row; ++i) {
            for (int j = 0; j < col; ++j) {
                std::cout << data[i][j] << ' ';
            }std::cout << '\n';
        }
    }

}



template<typename Dtype>
inline Matrix<Dtype> Matrix<Dtype>::power_n(int n) const {
    // ������Ԫ����n�η�
    Matrix<Dtype> power(row, col);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            power.data[i][j] = pow(data[i][j], n);
        }
    }
    return power;
}

template<typename Dtype>
inline Dtype Matrix<Dtype>::Ln_norm(int n) const {
    // 'vector' norm, for vector mainly.
    return pow(power_n(n).sum(), 1.0 / n);
}

template<typename Dtype>
inline Dtype Matrix<Dtype>::sum() const {
    Dtype tot(0);
    for (int i = 0; i < row; ++i) {
        for (int j = 0; j < col; ++j) {
            tot += data[i][j];
        }
    }
    return tot;
}

template<typename Dtype>
inline std::pair<int, Dtype> Matrix<Dtype>::max() const {
    int maxind(0);
    for (int i = 1; i < row; ++i) {
        if (data[i][0] > data[maxind][0]) {
            maxind = i;
        }
    }
    return std::make_pair(maxind, data[maxind][0]);
}

#endif // !_MATRIX_H_
