#ifndef _RELU_H_
#define _RELU_H_
#include "ActBase.h"
#include "../Matrix.h"

namespace ActFunc {
class ReLU : public ActBase{
public:
	Matrix<double> operator() (const Matrix<double>& z) const override;
	Matrix<double> diff(const Matrix<double>& z) const override;
};
}

#endif // !_RELU_H_
