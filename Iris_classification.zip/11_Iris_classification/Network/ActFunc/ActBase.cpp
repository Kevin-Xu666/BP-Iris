#include "ActBase.h"
namespace ActFunc {
	Matrix<double> ActBase::operator() (const Matrix<double>& z) const {
		return z;
	}
	Matrix<double> ActBase::diff(const Matrix<double>& z) const {
		return Matrix<double>(z.row, z.col, 1);
	}
}