#ifndef _SIGMOID_H_
#define _SIGMOID_H_
#include "ActBase.h"
#include "../Matrix.h"

namespace ActFunc {
class Sigmoid : public ActBase{
public:
	Matrix<double> operator() (const Matrix<double>& z) const override;
	Matrix<double> diff(const Matrix<double>& z) const override;
};
}

#endif // !_SIGMOID_H_
