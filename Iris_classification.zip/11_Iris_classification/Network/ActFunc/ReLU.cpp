#include "ReLU.h"
namespace ActFunc {
	Matrix<double> ReLU::operator() (const Matrix<double>& z) const {
		return z.apply([](double a) { return a > 0 ? a : 0.; });
	}
	Matrix<double> ReLU::diff(const Matrix<double>& z) const {
		return z.apply([](double a) { return a > 0 ? 1. : 0.; });
	}
}