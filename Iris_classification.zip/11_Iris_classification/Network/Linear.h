#ifndef _LINEAR_H_
#define _LINEAR_H_
#include "Matrix.h"
#include <string>
class Linear {
public:
	// ȫ���Ӳ�
	Matrix<double> weight, bias, activation;

	Linear(int in_dim, int out_dim);

	Matrix<double> forward(Matrix<double>&);
	Matrix<double> operator() (Matrix<double>&);
	void initialization(const std::string& method, double to = 0., double from = 1.);
};
#endif // !_LINEAR_H_
