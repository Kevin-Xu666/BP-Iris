#ifndef _BGD_H_
#define _BGD_H_
#include "OptimBase.h"
#include "../Matrix.h"
#include "../ActFunc.h"
#include "../Loss.h"
#include "../Net.h"

namespace Optim {
class BGD : public OptimBase
{
	// Batch Gradient Descent�Ż���
	std::vector<Matrix<double>> old_grad; // �洢�������Ķ���
public:
	Net& net;
	Loss::LossBase& lossfunc;
	double lr, mo;	//ѧϰ���붯��˥����

	BGD(Net& network, Loss::LossBase& loss, float learning_rate = 1e-2, float momentum = 0);
	void step(const Matrix<double>&, int) override;
	void zero_grad() override;
};

}
#endif // !_BGD_H_
