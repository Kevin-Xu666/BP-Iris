#include "BGD.h"

namespace Optim {

	BGD::BGD(Net& network, Loss::LossBase& loss, float learning_rate, float momentum)
		: net(network), lossfunc(loss), lr(learning_rate), mo(momentum){ 
		for (auto& fc : net.sequential) {
			old_grad.emplace_back(fc.weight.row, fc.weight.col, 0);
			old_grad.emplace_back(fc.bias.row, fc.bias.col, 0);
		}
	};

	void BGD::step(const Matrix<double>& input, int label){
		// ���򴫲�����㴫��delta
		auto& actfun = net.actfunc;
		auto& para = net.sequential;
		Matrix<double> delta = lossfunc.diff(para[para.size() - 1].activation, actfun, label);// +para[para.size() - 1].activation * 1e-3;
		for (int i = para.size() - 1; i > 0; --i) {
			auto& layer = para[i];
			auto& z = para[i - 1].activation;
			auto temp_delta = actfun.diff(z) DOT (layer.weight.T() * delta);
			old_grad[2 * i] = old_grad[2 * i] * mo + delta * actfun(z).T() * lr;
			old_grad[2 * i + 1] = old_grad[2 * i + 1] * mo + delta * lr;//��������������Ķ���
			layer.weight -= old_grad[2 * i];
			layer.bias -= old_grad[2 * i + 1];
			delta = temp_delta;
		}
		auto& layer = para[0];
		auto& x = input;
		old_grad[0] = old_grad[0] * mo + delta * x.T() * lr;
		old_grad[1] = old_grad[1] * mo + delta * lr;
		layer.weight -= old_grad[0];
		layer.bias -= old_grad[1];
	}
	void BGD::zero_grad() {
		// ������򴫲�����Ķ���洢��ûʲô��
		for (auto& layer : net.sequential) {
			layer.activation.free();
		}
		old_grad.clear();
	}

}