#include "OptimBase.h"
namespace Optim {

void OptimBase::step(const Matrix<double>& input, int label) {
	static_assert(1, "ERROR: Not Implemented.");
}

void OptimBase::zero_grad() {
	static_assert(1, "ERROR: Not Implemented.");
}

}