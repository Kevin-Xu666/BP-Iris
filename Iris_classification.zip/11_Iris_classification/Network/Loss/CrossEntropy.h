#ifndef _CELOSS_H_
#define _CELOSS_H_
#include "LossBase.h"
#include "../Matrix.h"
#include "../ActFunc.h"

namespace Loss {
class CrossEntropy : public LossBase
{
	// Pytorch�汾�Ľ�������ʧ����
public:
	double operator() (Matrix<double>& out, unsigned label) override;
	Matrix<double> diff(Matrix<double>& z, ActFunc::ActBase& act, unsigned label) override;
};
}

#endif // !_CELOSS_H_
