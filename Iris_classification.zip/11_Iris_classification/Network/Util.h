#include <fstream>
#include <string>
#include <vector>
#include "Matrix.h"
#include "Net.h"
#include "Loss.h"

void load_data(const std::string& file, 
	std::vector<std::pair<Matrix<double>, int> >& train, 
	std::vector<std::pair<Matrix<double>, int> >& test);
void shuffle(std::vector<std::pair<Matrix<double>, int>>& train);
std::pair<double, double> test(Net& mlp, Loss::LossBase& loss, std::vector<std::pair<Matrix<double>, int> >& test);
void print_res(std::vector<double> acc, std::vector<double> los);
